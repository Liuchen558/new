Jie Jie Gao (static web game)
Open with a local static server:

  npx --yes serve .

Then open the shown URL. Do not open index.html as a file:// URL.
